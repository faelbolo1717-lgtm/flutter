import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'profile_page.dart'; // Pastikan file ini sudah ada

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  String _searchQuery = '';

  Future<void> _bookRoom(Map<String, dynamic> room) async {
    final userId = Supabase.instance.client.auth.currentUser?.id;

    // Munculkan Kalender
    final DateTimeRange? pickedRange = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365)),
      saveText: 'KONFIRMASI',
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(primary: Colors.green),
          ),
          child: child!,
        );
      },
    );

    if (pickedRange == null) return;

    // Hitung total malam dan harga
    final int totalNights = pickedRange.duration.inDays;
    final num nightsForCalc = totalNights == 0 ? 1 : totalNights;
    final num totalPrice = nightsForCalc * room['price_per_night'];

    try {
      // Simpan ke tabel bookings
      await Supabase.instance.client.from('bookings').insert({
        'user_id': userId,
        'room_id': room['id'],
        'check_in': pickedRange.start.toIso8601String(),
        'check_out': pickedRange.end.toIso8601String(),
        'total_price': totalPrice,
      });

      // Update status kamar
      await Supabase.instance.client
          .from('rooms')
          .update({'is_available': false})
          .eq('id', room['id']);

      if (mounted) {
        _showSuccessDialog(room['room_number'], totalPrice, nightsForCalc.toInt());
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Gagal: $e"), backgroundColor: Colors.red),
      );
    }
  }

  void _showSuccessDialog(String roomNum, num price, int nights) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Booking Berhasil!"),
        content: Text(
            "Kamar $roomNum telah dipesan untuk $nights malam.\nTotal: Rp $price"),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(context), child: const Text("OK"))
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final _roomsStream = Supabase.instance.client
        .from('rooms')
        .stream(primaryKey: ['id']).order('room_number');

    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text("EcoStay Explorer",
            style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.green[700],
        foregroundColor: Colors.white,
        actions: [
          // TOMBOL MENU PROFIL
          IconButton(
            icon: const Icon(Icons.person),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const ProfilePage()),
              );
            },
          ),
          // TOMBOL LOGOUT
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () => Supabase.instance.client.auth.signOut(),
          )
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: TextField(
              onChanged: (value) => setState(() => _searchQuery = value),
              decoration: InputDecoration(
                hintText: "Cari nomor atau tipe kamar...",
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(30),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          Expanded(
            child: StreamBuilder<List<Map<String, dynamic>>>(
              stream: _roomsStream,
              builder: (context, snapshot) {
                if (!snapshot.hasData) {
                  return const Center(child: CircularProgressIndicator());
                }

                final rooms = snapshot.data!.where((room) {
                  final roomNum = room['room_number'].toString().toLowerCase();
                  final type = room['room_type'].toString().toLowerCase();
                  return roomNum.contains(_searchQuery.toLowerCase()) ||
                      type.contains(_searchQuery.toLowerCase());
                }).toList();

                return ListView.builder(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  itemCount: rooms.length,
                  itemBuilder: (context, index) {
                    final room = rooms[index];
                    final isAvail = room['is_available'] ?? false;

                    return Card(
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(15)),
                      margin: const EdgeInsets.only(bottom: 16),
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            Container(
                              height: 80,
                              width: 80,
                              decoration: BoxDecoration(
                                color:
                                    isAvail ? Colors.green[50] : Colors.red[50],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Icon(
                                room['room_type'] == 'Hotel'
                                    ? Icons.hotel
                                    : Icons.home_work,
                                size: 40,
                                color: isAvail ? Colors.green : Colors.red,
                              ),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    "Kamar ${room['room_number']}",
                                    style: const TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold),
                                  ),
                                  // Menggunakan room_type sesuai tabel SQL Anda
                                  Text(room['room_type'] ?? 'Tipe Umum',
                                      style:
                                          TextStyle(color: Colors.grey[600])),
                                  const SizedBox(height: 8),
                                  Text(
                                    "Rp ${room['price_per_night']}",
                                    style: const TextStyle(
                                        color: Colors.green,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),
                            ),
                            ElevatedButton(
                              onPressed: isAvail ? () => _bookRoom(room) : null,
                              style: ElevatedButton.styleFrom(
                                backgroundColor:
                                    isAvail ? Colors.green : Colors.grey[300],
                                foregroundColor: Colors.white,
                                elevation: 0,
                                shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(10)),
                              ),
                              child: Text(isAvail ? "Pesan" : "Full"),
                            ),
                          ],
                        ),
                      ),
                    );
                  },
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}