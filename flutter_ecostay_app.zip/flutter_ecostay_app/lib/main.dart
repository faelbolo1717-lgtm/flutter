import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'login_page.dart';
import 'home_page.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  await Supabase.initialize(
    url: 'https://xjqwlvkxomykgtugyfyf.supabase.co',
    anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InhqcXdsdmt4b215a2d0dWd5ZnlmIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjgxOTc3ODAsImV4cCI6MjA4Mzc3Mzc4MH0.aWntPaBSH0e5JA-wFFr30IRNYDvfmyH_s7q0_p5NAlA',
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
   
    final session = Supabase.instance.client.auth.currentSession;

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'EcoStay',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.green),
        useMaterial3: true,
      ),
      // Jika session tidak null, langsung ke HomePage
      home: session != null ? const HomePage() : const LoginPage(),
      // Daftarkan route untuk navigasi
      routes: {
        '/login': (context) => const LoginPage(),
        '/home': (context) => const HomePage(),
      },
    );
  }
}